"use client"

import { useState } from "react"
import { LayoutDashboard, Film, Heart, BarChart3, User } from "lucide-react"
import { Dashboard } from "@/components/pages/dashboard"
import { Movies } from "@/components/pages/movies"
import { Favorites } from "@/components/pages/favorites"
import { Statistics } from "@/components/pages/statistics"
import { Profile } from "@/components/pages/profile"

export default function Home() {
  const [currentTab, setCurrentTab] = useState("dashboard")

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "movies", label: "Películas", icon: Film },
    { id: "favorites", label: "Favoritos", icon: Heart },
    { id: "statistics", label: "Estadísticas", icon: BarChart3 },
    { id: "profile", label: "Perfil", icon: User },
  ]

  const renderContent = () => {
    switch (currentTab) {
      case "movies":
        return <Movies />
      case "favorites":
        return <Favorites />
      case "statistics":
        return <Statistics />
      case "profile":
        return <Profile />
      case "dashboard":
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-2xl font-bold text-blue-400">🎬 MovieHub</h1>
        </div>
      </header>

      {/* Tabs Navigation */}
      <div className="bg-slate-900 border-b border-slate-800 overflow-x-auto">
        <div className="max-w-7xl mx-auto">
          <div className="flex gap-0">
            {tabs.map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setCurrentTab(tab.id)}
                  className={`flex items-center gap-2 px-4 sm:px-6 py-3 border-b-2 transition-colors whitespace-nowrap text-sm sm:text-base ${
                    currentTab === tab.id
                      ? "border-blue-500 text-blue-400 bg-slate-800/50"
                      : "border-transparent text-slate-400 hover:text-slate-300 hover:bg-slate-800/30"
                  }`}
                >
                  <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">{renderContent()}</main>
    </div>
  )
}

"use client"

import { LayoutDashboard, Film, Heart, BarChart3, User, LogIn } from "lucide-react"
import { useState } from "react"
import { LoginForm } from "@/components/forms/login-form"

interface SidebarProps {
  isOpen: boolean
  currentPage: string
  setCurrentPage: (page: string) => void
}

export function Sidebar({ isOpen, currentPage, setCurrentPage }: SidebarProps) {
  const [showLoginModal, setShowLoginModal] = useState(false)
  const isLoggedIn = localStorage.getItem("userId")

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "movies", label: "Películas", icon: Film },
    { id: "favorites", label: "Favoritos", icon: Heart },
    { id: "statistics", label: "Estadísticas", icon: BarChart3 },
    { id: "profile", label: "Perfil", icon: User },
  ]

  return (
    <>
      <aside
        className={`bg-slate-900 border-r border-slate-800 transition-all duration-300 ${isOpen ? "w-64" : "w-20"} flex flex-col`}
      >
        <div className="p-4 border-b border-slate-800">
          <h1 className={`font-bold text-xl text-blue-400 ${!isOpen && "text-center"}`}>
            {isOpen ? "🎬 MovieHub" : "🎬"}
          </h1>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {isLoggedIn ? (
            menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  currentPage === item.id ? "bg-blue-600 text-white" : "text-slate-300 hover:bg-slate-800"
                }`}
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                {isOpen && <span className="text-sm font-medium">{item.label}</span>}
              </button>
            ))
          ) : (
            <button
              onClick={() => setShowLoginModal(true)}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors bg-blue-600 text-white hover:bg-blue-700"
            >
              <LogIn className="w-5 h-5 flex-shrink-0" />
              {isOpen && <span className="text-sm font-medium">Iniciar sesión</span>}
            </button>
          )}
        </nav>
      </aside>

      {showLoginModal && <LoginForm onClose={() => setShowLoginModal(false)} />}
    </>
  )
}

"use client"

import { Menu, LogOut, User } from "lucide-react"
import { useState } from "react"

interface HeaderProps {
  onToggleSidebar: () => void
}

export function Header({ onToggleSidebar }: HeaderProps) {
  const [showUserMenu, setShowUserMenu] = useState(false)
  const currentUser = localStorage.getItem("currentUser")

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    localStorage.removeItem("userId")
    window.location.reload()
  }

  return (
    <header className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
      <button onClick={onToggleSidebar} className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
        <Menu className="w-6 h-6" />
      </button>

      <div className="flex items-center gap-4 relative">
        <button
          onClick={() => setShowUserMenu(!showUserMenu)}
          className="flex items-center gap-2 px-4 py-2 hover:bg-slate-800 rounded-lg transition-colors"
        >
          <User className="w-5 h-5" />
          <span className="text-sm font-medium">{currentUser || "Guest"}</span>
        </button>

        {showUserMenu && (
          <div className="absolute top-full right-0 mt-2 w-48 bg-slate-800 rounded-lg shadow-lg border border-slate-700 z-50">
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-2 px-4 py-2 text-red-400 hover:bg-slate-700 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Cerrar sesión</span>
            </button>
          </div>
        )}
      </div>
    </header>
  )
}

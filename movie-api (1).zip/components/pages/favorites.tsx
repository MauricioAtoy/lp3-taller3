"use client"

import { useEffect, useState } from "react"
import { API_BASE_URL } from "@/lib/api"
import { Trash2 } from "lucide-react"

interface Favorite {
  id: number
  id_usuario?: number
  id_pelicula: number
  pelicula: {
    id: number
    titulo: string
    director: string
    genero: string
    año: number
    clasificacion: string
  }
  fecha_marcado: string
}

export function Favorites() {
  const [favorites, setFavorites] = useState<Favorite[]>([])
  const [loading, setLoading] = useState(true)
  const userId = localStorage.getItem("userId")

  useEffect(() => {
    const loadFavorites = async () => {
      try {
        if (userId) {
          // Usuario autenticado - traer desde API
          const response = await fetch(`${API_BASE_URL}/favoritos/usuario/${userId}`)
          const data = await response.json()
          setFavorites(data)
        } else {
          // Usuario anónimo - cargar desde localStorage
          const savedFavorites = localStorage.getItem("localFavorites")
          if (savedFavorites) {
            setFavorites(JSON.parse(savedFavorites))
          }
        }
      } catch (error) {
        console.error("[v0] Error loading favorites:", error)
        // Fallback a localStorage
        const savedFavorites = localStorage.getItem("localFavorites")
        if (savedFavorites) {
          setFavorites(JSON.parse(savedFavorites))
        }
      } finally {
        setLoading(false)
      }
    }

    loadFavorites()
  }, [userId])

  const removeFavorite = async (favoriteId: number) => {
    try {
      if (userId) {
        await fetch(`${API_BASE_URL}/favoritos/${favoriteId}`, {
          method: "DELETE",
        })
      }
      setFavorites(favorites.filter((f) => f.id !== favoriteId))

      if (!userId) {
        localStorage.setItem("localFavorites", JSON.stringify(favorites.filter((f) => f.id !== favoriteId)))
      }
    } catch (error) {
      console.error("[v0] Error removing favorite:", error)
    }
  }

  if (loading) {
    return <div className="text-center py-8">Cargando favoritos...</div>
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Mis Favoritos</h1>

      {favorites.length === 0 ? (
        <div className="text-center py-8 text-slate-400">
          <p>No tienes películas favoritas aún</p>
          <p className="text-sm mt-2">Marca películas como favoritas desde la sección de Películas</p>
        </div>
      ) : (
        <div className="space-y-3">
          {favorites.map((favorite) => (
            <div
              key={favorite.id}
              className="bg-slate-900 rounded-lg border border-slate-800 p-4 flex items-center justify-between hover:border-blue-600 transition-colors"
            >
              <div className="flex-1">
                <h3 className="font-bold text-lg">{favorite.pelicula.titulo}</h3>
                <p className="text-sm text-slate-400">
                  {favorite.pelicula.director} • {favorite.pelicula.año} • {favorite.pelicula.clasificacion}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Agregado: {new Date(favorite.fecha_marcado).toLocaleDateString()}
                </p>
              </div>
              <button
                onClick={() => removeFavorite(favorite.id)}
                className="p-2 text-red-400 hover:bg-red-600/20 rounded-lg transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

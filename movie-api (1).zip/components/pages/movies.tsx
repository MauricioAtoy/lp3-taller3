"use client"

import { useEffect, useState } from "react"
import { API_BASE_URL } from "@/lib/api"
import { Search, Heart } from "lucide-react"

interface Movie {
  id: number
  titulo: string
  director: string
  genero: string
  año: number
  clasificacion: string
  duracion: number
  sinopsis: string
}

export function Movies() {
  const [movies, setMovies] = useState<Movie[]>([])
  const [filteredMovies, setFilteredMovies] = useState<Movie[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filters, setFilters] = useState({
    genre: "",
    director: "",
    year: "",
    classification: "",
  })

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/peliculas/`)
        const data = await response.json()
        setMovies(data)
        setFilteredMovies(data)
      } catch (error) {
        console.error("[v0] Error fetching movies:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchMovies()
  }, [])

  useEffect(() => {
    let result = movies

    if (searchTerm) {
      result = result.filter(
        (movie) =>
          movie.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
          movie.director.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (filters.genre) {
      result = result.filter((movie) => movie.genero === filters.genre)
    }

    if (filters.director) {
      result = result.filter((movie) => movie.director.toLowerCase().includes(filters.director.toLowerCase()))
    }

    if (filters.year) {
      result = result.filter((movie) => movie.año === Number.parseInt(filters.year))
    }

    if (filters.classification) {
      result = result.filter((movie) => movie.clasificacion === filters.classification)
    }

    setFilteredMovies(result)
  }, [searchTerm, filters, movies])

  if (loading) {
    return <div className="text-center py-8">Cargando películas...</div>
  }

  const genres = [...new Set(movies.map((m) => m.genero))]
  const classifications = [...new Set(movies.map((m) => m.clasificacion))]

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Explorador de Películas</h1>

      <div className="bg-slate-900 rounded-lg border border-slate-800 p-6 space-y-4">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-500" />
            <input
              type="text"
              placeholder="Buscar película o director..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-10 pr-4 py-2 text-slate-50 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Género</label>
            <select
              value={filters.genre}
              onChange={(e) => setFilters({ ...filters, genre: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos</option>
              {genres.map((genre) => (
                <option key={genre} value={genre}>
                  {genre}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Director</label>
            <input
              type="text"
              placeholder="Nombre director..."
              value={filters.director}
              onChange={(e) => setFilters({ ...filters, director: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-50 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Año</label>
            <input
              type="number"
              placeholder="2024"
              value={filters.year}
              onChange={(e) => setFilters({ ...filters, year: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-50 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Clasificación</label>
            <select
              value={filters.classification}
              onChange={(e) => setFilters({ ...filters, classification: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todas</option>
              {classifications.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMovies.map((movie) => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>

      {filteredMovies.length === 0 && (
        <div className="text-center py-8 text-slate-400">No se encontraron películas</div>
      )}
    </div>
  )
}

function MovieCard({ movie }: { movie: Movie }) {
  const userId = localStorage.getItem("userId")
  const [isFavorite, setIsFavorite] = useState(false)

  useEffect(() => {
    checkFavorite()
  }, [userId])

  const checkFavorite = () => {
    if (userId) {
      // Check in API for logged in users
      checkFavoriteInAPI()
    } else {
      // Check in localStorage for anonymous users
      const savedFavorites = localStorage.getItem("localFavorites")
      if (savedFavorites) {
        const favorites = JSON.parse(savedFavorites)
        setIsFavorite(favorites.some((f: any) => f.id_pelicula === movie.id))
      }
    }
  }

  const checkFavoriteInAPI = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/favoritos/verificar/${userId}/${movie.id}`)
      if (response.ok) {
        setIsFavorite(true)
      }
    } catch (error) {
      console.error("[v0] Error checking favorite:", error)
    }
  }

  const toggleFavorite = async () => {
    try {
      if (userId) {
        // API favoriting for logged in users
        if (isFavorite) {
          await fetch(`${API_BASE_URL}/favoritos/usuario/${userId}/todos`, {
            method: "DELETE",
          })
        } else {
          await fetch(`${API_BASE_URL}/favoritos/`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id_usuario: Number.parseInt(userId), id_pelicula: movie.id }),
          })
        }
        setIsFavorite(!isFavorite)
      } else {
        // localStorage favoriting for anonymous users
        const savedFavorites = localStorage.getItem("localFavorites")
        let favorites = savedFavorites ? JSON.parse(savedFavorites) : []

        if (isFavorite) {
          favorites = favorites.filter((f: any) => f.id_pelicula !== movie.id)
        } else {
          favorites.push({
            id: Date.now(),
            id_pelicula: movie.id,
            pelicula: movie,
            fecha_marcado: new Date().toISOString(),
          })
        }

        localStorage.setItem("localFavorites", JSON.stringify(favorites))
        setIsFavorite(!isFavorite)
      }
    } catch (error) {
      console.error("[v0] Error toggling favorite:", error)
    }
  }

  return (
    <div className="bg-slate-900 rounded-lg border border-slate-800 p-4 hover:border-blue-600 transition-colors">
      <div className="mb-3">
        <h3 className="font-bold text-lg line-clamp-2">{movie.titulo}</h3>
        <p className="text-sm text-slate-400">{movie.director}</p>
      </div>
      <div className="space-y-1 text-sm text-slate-400 mb-3">
        <p>
          {movie.genero} • {movie.año}
        </p>
        <p>
          {movie.duracion} min • {movie.clasificacion}
        </p>
      </div>
      <p className="text-sm line-clamp-2 mb-4">{movie.sinopsis}</p>
      <button
        onClick={toggleFavorite}
        className={`w-full py-2 rounded-lg transition-colors flex items-center justify-center gap-2 font-medium ${
          isFavorite ? "bg-red-600 text-white hover:bg-red-700" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
        }`}
      >
        <Heart className={`w-4 h-4 ${isFavorite ? "fill-current" : ""}`} />
        {isFavorite ? "Favorito" : "Agregar a favoritos"}
      </button>
    </div>
  )
}

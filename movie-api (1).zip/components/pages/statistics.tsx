"use client"

import { useEffect, useState } from "react"
import { API_BASE_URL } from "@/lib/api"

export function Statistics() {
  const [stats, setStats] = useState({
    genreStats: {} as Record<string, number>,
    yearStats: {} as Record<number, number>,
    classificationStats: {} as Record<string, number>,
    averageFavoritesPerMovie: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const moviesRes = await fetch(`${API_BASE_URL}/peliculas/`)
        const favoritesRes = await fetch(`${API_BASE_URL}/favoritos/`)

        const movies = await moviesRes.json()
        const favorites = await favoritesRes.json()

        const genreStats: Record<string, number> = {}
        const yearStats: Record<number, number> = {}
        const classificationStats: Record<string, number> = {}

        movies.forEach((movie: any) => {
          genreStats[movie.genero] = (genreStats[movie.genero] || 0) + 1
          yearStats[movie.año] = (yearStats[movie.año] || 0) + 1
          classificationStats[movie.clasificacion] = (classificationStats[movie.clasificacion] || 0) + 1
        })

        setStats({
          genreStats,
          yearStats,
          classificationStats,
          averageFavoritesPerMovie: movies.length > 0 ? favorites.length / movies.length : 0,
        })
      } catch (error) {
        console.error("[v0] Error fetching statistics:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [])

  if (loading) {
    return <div className="text-center py-8">Cargando estadísticas...</div>
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Estadísticas</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
          <h2 className="text-xl font-bold mb-4">Películas por Género</h2>
          <div className="space-y-2">
            {Object.entries(stats.genreStats).map(([genre, count]) => (
              <div key={genre} className="flex items-center justify-between">
                <span className="text-slate-300">{genre}</span>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500"
                      style={{
                        width: `${(count / Object.values(stats.genreStats).reduce((a, b) => a + b, 0)) * 100}%`,
                      }}
                    />
                  </div>
                  <span className="font-bold text-blue-400 w-6 text-right">{count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
          <h2 className="text-xl font-bold mb-4">Películas por Clasificación</h2>
          <div className="space-y-2">
            {Object.entries(stats.classificationStats).map(([classification, count]) => (
              <div key={classification} className="flex items-center justify-between">
                <span className="text-slate-300">{classification}</span>
                <span className="font-bold text-blue-400">{count} películas</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-900 rounded-lg border border-slate-800 p-6 md:col-span-2">
          <h2 className="text-xl font-bold mb-4">Películas por Año</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(stats.yearStats)
              .sort((a, b) => Number.parseInt(b[0]) - Number.parseInt(a[0]))
              .slice(0, 8)
              .map(([year, count]) => (
                <div key={year} className="bg-slate-800 rounded-lg p-3 text-center">
                  <p className="font-bold text-blue-400">{count}</p>
                  <p className="text-sm text-slate-400">{year}</p>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  )
}

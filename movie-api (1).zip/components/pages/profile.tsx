"use client"

import { useEffect, useState } from "react"
import { API_BASE_URL } from "@/lib/api"
import { Edit2, Save, X, LogOut } from "lucide-react"

interface UserProfile {
  id: number
  nombre: string
  correo: string
  fecha_registro: string
}

export function Profile() {
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({ nombre: "", correo: "" })
  const [showLoginPrompt, setShowLoginPrompt] = useState(false)
  const userId = localStorage.getItem("userId")

  useEffect(() => {
    if (!userId) {
      setLoading(false)
      setShowLoginPrompt(true)
      return
    }

    const fetchProfile = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/usuarios/${userId}`)
        const data = await response.json()
        setProfile(data)
        setFormData({ nombre: data.nombre, correo: data.correo })
      } catch (error) {
        console.error("[v0] Error fetching profile:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [userId])

  const handleSave = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/usuarios/${userId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })
      const updated = await response.json()
      setProfile(updated)
      setIsEditing(false)
    } catch (error) {
      console.error("[v0] Error updating profile:", error)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("userId")
    localStorage.removeItem("currentUser")
    window.location.reload()
  }

  if (loading) {
    return <div className="text-center py-8">Cargando...</div>
  }

  if (showLoginPrompt) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Mi Perfil</h1>
        <div className="bg-slate-900 rounded-lg border border-slate-800 p-8 max-w-md text-center">
          <p className="text-slate-400 mb-4">Para ver y editar tu perfil, necesitas iniciar sesión</p>
          <button
            onClick={() => {
              const email = prompt("Ingresa tu email:")
              if (email) {
                localStorage.setItem("userId", Date.now().toString())
                localStorage.setItem("currentUser", email)
                window.location.reload()
              }
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors"
          >
            Iniciar sesión
          </button>
        </div>
      </div>
    )
  }

  if (!profile) {
    return <div className="text-center py-8">Perfil no encontrado</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Mi Perfil</h1>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Cerrar sesión
        </button>
      </div>

      <div className="bg-slate-900 rounded-lg border border-slate-800 p-8 max-w-md">
        {!isEditing ? (
          <div className="space-y-4">
            <div>
              <p className="text-slate-400 text-sm">Nombre</p>
              <p className="text-xl font-bold">{profile.nombre}</p>
            </div>
            <div>
              <p className="text-slate-400 text-sm">Email</p>
              <p className="text-xl font-bold">{profile.correo}</p>
            </div>
            <div>
              <p className="text-slate-400 text-sm">Fecha de registro</p>
              <p className="text-slate-300">{new Date(profile.fecha_registro).toLocaleDateString()}</p>
            </div>
            <button
              onClick={() => setIsEditing(true)}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors mt-4"
            >
              <Edit2 className="w-4 h-4" />
              Editar perfil
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Nombre</label>
              <input
                type="text"
                value={formData.nombre}
                onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <input
                type="email"
                value={formData.correo}
                onChange={(e) => setFormData({ ...formData, correo: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex gap-2 mt-4">
              <button
                onClick={handleSave}
                className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-medium py-2 rounded-lg transition-colors"
              >
                <Save className="w-4 h-4" />
                Guardar
              </button>
              <button
                onClick={() => setIsEditing(false)}
                className="flex-1 flex items-center justify-center gap-2 bg-slate-700 hover:bg-slate-600 text-white font-medium py-2 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
                Cancelar
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

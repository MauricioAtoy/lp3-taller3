"use client"

import { useEffect, useState } from "react"
import { apiFetch } from "@/lib/api"

interface DashboardStats {
  totalUsers: number
  totalMovies: number
  totalFavorites: number
  topMovies: any[]
}

export function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalMovies: 0,
    totalFavorites: 0,
    topMovies: [],
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    const fetchStats = async () => {
      try {
        console.log("[v0] Iniciando fetch de estadísticas...")

        const fetchWithFallback = async (endpoint: string) => {
          try {
            return await apiFetch(endpoint)
          } catch (err) {
            console.warn(`[v0] Failed to fetch ${endpoint}:`, err)
            return []
          }
        }

        const [usersRes, moviesRes, favoritesRes] = await Promise.all([
          fetchWithFallback("/usuarios/"),
          fetchWithFallback("/peliculas/"),
          fetchWithFallback("/favoritos/"),
        ])

        const users = Array.isArray(usersRes) ? usersRes : []
        const movies = Array.isArray(moviesRes) ? moviesRes : []
        const favorites = Array.isArray(favoritesRes) ? favoritesRes : []

        setStats({
          totalUsers: users.length,
          totalMovies: movies.length,
          totalFavorites: favorites.length,
          topMovies: movies.slice(0, 5),
        })

        if (users.length === 0 && movies.length === 0) {
          setError("No se pudieron cargar los datos. Asegúrate de que la API esté ejecutándose en la URL configurada.")
        }
      } catch (err) {
        console.error("[v0] Error fetching stats:", err)
        setError("Error conectando con la API. Verifica NEXT_PUBLIC_API_URL en tu configuración.")
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [])

  if (loading) {
    return <div className="text-center py-8 text-slate-400">Cargando estadísticas...</div>
  }

  if (error) {
    return <div className="bg-red-600/20 border border-red-600 rounded-lg p-4 text-red-400 text-sm">{error}</div>
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard title="Usuarios" value={stats.totalUsers} />
        <StatCard title="Películas" value={stats.totalMovies} />
        <StatCard title="Favoritos" value={stats.totalFavorites} />
      </div>

      <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
        <h2 className="text-xl font-bold mb-4">Películas destacadas</h2>
        {stats.topMovies.length > 0 ? (
          <div className="space-y-3">
            {stats.topMovies.map((movie: any) => (
              <div key={movie.id} className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
                <div>
                  <p className="font-semibold">{movie.titulo}</p>
                  <p className="text-sm text-slate-400">
                    {movie.director} - {movie.año}
                  </p>
                </div>
                <span className="text-yellow-400">{movie.clasificacion}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-slate-400">No hay películas disponibles</p>
        )}
      </div>
    </div>
  )
}

function StatCard({ title, value }: { title: string; value: number }) {
  return (
    <div className="bg-slate-900 rounded-lg border border-slate-800 p-6">
      <p className="text-slate-400 text-sm">{title}</p>
      <p className="text-3xl font-bold text-blue-400 mt-2">{value}</p>
    </div>
  )
}

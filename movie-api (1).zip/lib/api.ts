export const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

export async function apiFetch(endpoint: string, options?: RequestInit) {
  const url = `${API_BASE_URL}${endpoint}`

  console.log("[v0] Fetching from:", url)

  try {
    const response = await fetch(url, {
      ...options,
      mode: "cors",
      credentials: "omit",
      headers: {
        "Content-Type": "application/json",
        ...options?.headers,
      },
    })

    if (!response.ok) {
      const contentType = response.headers.get("content-type")
      let errorMsg = `API error: ${response.status}`

      if (contentType?.includes("application/json")) {
        try {
          const errorData = await response.json()
          errorMsg = errorData.detail || errorMsg
        } catch {
          // If JSON parsing fails, use default error message
        }
      }

      throw new Error(errorMsg)
    }

    const contentType = response.headers.get("content-type")
    if (!contentType?.includes("application/json")) {
      throw new Error("API returned non-JSON response. Check the API URL and endpoint.")
    }

    const data = await response.json()
    console.log("[v0] API response:", data)
    return data
  } catch (error) {
    console.error("[v0] API fetch error:", error instanceof Error ? error.message : error)
    throw error
  }
}
